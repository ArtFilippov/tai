import json
import os
import pty
import select
import struct
import subprocess
import sys
import termios
import fcntl
import hashlib
import tarfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from functools import partial
from pathlib import Path
from time import monotonic

from app.configuration import load_profile
from core.chats import LLMChat
from core.chats.qwen_server import QwenServer
from core.primitives.messages import Message

ROOT = Path('/29a_fil/.opencode/tmp/interactive/opencode/tai-issue23-acceptance')
ROOT.mkdir(exist_ok=True)
PROFILE = ROOT / 'profile.toml'
PROFILE.write_text(Path('examples/fitd-alert-vllm.toml').read_text().replace(
    '/vg/isp/tai/environments/vllm/.venv/bin/python',
    '/29a_fil/.opencode/tmp/interactive/opencode/tai-issue23-vllm/bin/python'))


def smoke():
    profile = load_profile(PROFILE)
    config = profile.assembly.server.config
    server = QwenServer(config, ROOT / 'smoke-vllm.log')
    initial = server.settings()
    spans = []

    def send(number):
        chat = LLMChat.cancellable(partial(server.generate, generation={'max_new_tokens': 64}), system='Answer briefly and accurately.')
        began = monotonic()
        response = chat.send(Message(f'What is {number} plus two?'))
        spans.append({'number': number, 'start': began, 'end': monotonic(), 'response': response.text,
                      'conversation_id': chat.conversation_id})

    with server, ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(send, [2, 3, 4]))
        ready = server.settings()
    (ROOT / 'smoke.json').write_text(json.dumps({'initial': initial, 'ready': ready, 'closed': server.settings(), 'spans': spans}, indent=2))
    print('smoke passed', flush=True)


def preflight():
    result = subprocess.run([str(Path(sys.executable).with_name('tai')), 'preflight', '--config', str(PROFILE), '--report', str(ROOT/'preflight.json')], capture_output=True)
    (ROOT/'preflight.stdout').write_bytes(result.stdout)
    (ROOT/'preflight.stderr').write_bytes(result.stderr)
    print('preflight', result.returncode, flush=True)


def snapshot(directory):
    files = sorted(Path('src').rglob('*.py')) + [Path(name) for name in ['pyproject.toml', 'uv.lock', 'tach.toml', 'examples/alert-manifest.json', 'examples/fitd-alert-vllm.toml', 'ALERT_taxonomy.md', 'environments/vllm/pyproject.toml', 'environments/vllm/uv.lock']]
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    (directory / 'source.json').write_text(json.dumps({'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'status': subprocess.check_output(['git', 'status', '--short'], text=True), 'sha256': hashes}, indent=2))
    with tarfile.open(directory / 'source.tar.gz', 'w:gz') as archive:
        for path in files:
            archive.add(path, arcname=str(path))
    return hashes


def series(interrupt=False):
    name = 'interrupt-final' if interrupt else 'full-final'
    directory = ROOT / name
    directory.mkdir(exist_ok=True)
    hashes = snapshot(directory)
    command = [str(Path(sys.executable).with_name('tai')), 'alert-series', '--jobs', '4', '--manifest', str(Path('examples/alert-manifest.json').resolve()), '--profile', str(PROFILE), '--taxonomy', str(Path('ALERT_taxonomy.md').resolve()), '--artifacts-dir', str(directory)]
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 14, 180, 0, 0))
    began = monotonic()
    interrupted = False
    with (directory/'stdout.json').open('wb') as output, (directory/'console.ansi').open('wb') as console:
        with subprocess.Popen(command, stdout=output, stderr=slave, env={**os.environ, 'TERM': 'xterm-256color'}, start_new_session=True) as process:
            os.close(slave)
            while process.poll() is None:
                readable, _, _ = select.select([master], [], [], .1)
                if readable:
                    try:
                        console.write(os.read(master, 65536))
                    except OSError:
                        break
                if interrupt and not interrupted:
                    journals = list(directory.glob('*/runs/*/events.jsonl'))
                    if len(journals) == 4 and all('call_completed' in path.read_text() for path in journals):
                        process.send_signal(2)
                        process.send_signal(2)
                        interrupted = True
            code = process.wait()
            try:
                while select.select([master], [], [], .1)[0]:
                    console.write(os.read(master, 65536))
            except OSError:
                pass
    os.close(master)
    (directory/'command.json').write_text(json.dumps({'command': command, 'exit_code': code, 'duration': monotonic()-began, 'sigint_sent': interrupted}, indent=2))
    (directory/'source-check.json').write_text(json.dumps({'unchanged': all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in hashes.items())}, indent=2))
    print(name, code, monotonic()-began, flush=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'preflight':
        preflight()
    elif mode == 'smoke':
        smoke()
        preflight()
    else:
        series(mode == 'interrupt')
