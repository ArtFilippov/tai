import hashlib
import json
import re
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path('/29a_fil/.opencode/tmp/interactive/opencode/tai-issue23-acceptance')


def verify(name):
    root = ROOT / name
    output = json.loads((root/'stdout.json').read_text())
    directory = root / output['series_id']
    index = json.loads((directory/'index.json').read_text())
    spans = []
    pids = set()
    errors = []
    role_ids = set()
    for entry in index['entries']:
        metadata = json.loads((directory/entry['artifacts']['metadata.json']).read_text())
        for key in ['run_id', 'state', 'reason', 'progress', 'result_id', 'evaluation']:
            assert entry[key] == metadata[key], (entry['sequence'], key)
        assert metadata['settings']['base']['id'] == entry['base_id']
        assert index['planned'][entry['sequence']-1]['id'] == entry['id']
        assert metadata['settings']['max_calls_per_conv'] == 20
        assert metadata['settings']['generations'] == 1
        if entry['result']:
            assert metadata['result']['id'] == entry['result_id']
            assert metadata['result']['text'] == (directory/entry['artifacts']['result.txt']).read_text()
        events = [json.loads(line) for line in (directory/entry['artifacts']['events.jsonl']).read_text().splitlines()]
        assert all(event['run_id'] == entry['run_id'] for event in events)
        assert any(event['kind'] == 'resources_released' for event in events)
        starts = {event['data']['call_id']: event for event in events if event['kind'] == 'call_started'}
        for event in events:
            if event['kind'] == 'call_completed':
                start = starts[event['data']['call_id']]
                spans.append({'sequence': entry['sequence'], 'role': event['data']['role'], 'start': start['timestamp'], 'end': event['timestamp'], 'call_id': event['data']['call_id']})
        if entry['evaluation']:
            assert any(event['kind'] == 'evaluation_completed' and all(event['data'][key] == value for key, value in entry['evaluation'].items()) for event in events)
        for role in ['Target', 'Attacker', 'Evaluator']:
            settings = metadata['final_settings'][role]
            pids.add(settings['server']['pid'])
            role_ids.add(metadata['settings'][role]['conversation_id'])
            assert settings['server']['version'] == '0.6.4.post1'
            assert settings['server']['dtype'] == 'float16'
        if entry['state'] == 'FAILED':
            errors.append({'sequence': entry['sequence'], 'id': entry['id'], 'category': entry['micro_category'], 'reason': entry['reason']})
    assert len(role_ids) == 3*len(index['entries'])
    assert len(pids) == 1
    rebuilt = subprocess.run([str(Path(sys.executable).with_name('tai')), 'alert-report', '--index', str(directory/'index.json')], capture_output=True, check=True)
    assert rebuilt.stdout == (directory/'report.json').read_bytes() == (root/'stdout.json').read_bytes()
    (root/'rebuilt.json').write_bytes(rebuilt.stdout)
    for macro, counts in output['groups'].items():
        entries = [entry for entry in index['entries'] if entry['macro_category'] == macro]
        valid = [entry for entry in entries if entry['state'] == 'COMPLETED' and not entry['error'] and not entry['storage_error'] and not entry['artifact_errors'] and entry['result'] and entry['evaluation'] and type(entry['evaluation']['success']) is bool and entry['result_id'] == entry['evaluation']['result_id'] == entry['result']['id']]
        success = sum(entry['evaluation']['success'] for entry in valid)
        assert counts == {'total':len(entries), 'evaluated':len(valid), 'successful':success, 'unevaluated':len(entries)-len(valid), 'success_percent':100*success/len(valid) if valid else None}
    cutoff = min(span['end'] for span in spans)
    points = [(span[bound], change, span['sequence']) for span in spans if span['start'] > cutoff for bound, change in [('start',1),('end',-1)]]
    active, maximum = set(), 0
    for stamp, change, sequence in sorted(points):
        if change > 0:
            active.add(sequence)
        else:
            active.remove(sequence)
        maximum = max(maximum, len(active))
    workers = []
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            values = path.read_text().rsplit(') ',1)[1].split()
            if int(values[2]) in pids and values[0] != 'Z':
                workers.append(str(path.parent))
        except (OSError, ValueError, IndexError):
            pass
    assert not workers
    log = (directory/'vllm.log').read_text()
    loads = log.count('Loading model weights took')
    assert loads == 1
    batches = [int(value) for value in re.findall(r'Running: (\d+) reqs', log)]
    summary = {'series_id':output['series_id'], 'entries':len(index['entries']), 'states':dict(Counter(entry['state'] for entry in index['entries'])), 'errors':errors, 'completed_model_calls':len(spans), 'maximum_overlapping_runs_after_first_response':maximum, 'server_running_requests_max':max(batches, default=0), 'model_loads':loads, 'server_pids':sorted(pids), 'remaining_live_processes':workers, 'report_byte_identical':True, 'groups':output['groups'], 'duration_seconds':index['duration_seconds']}
    (root/'verified.json').write_text(json.dumps(summary, indent=2))
    (root/'intervals.json').write_text(json.dumps(spans, indent=2))
    print(json.dumps(summary, indent=2))


verify('full-final')
verify('interrupt-final')
